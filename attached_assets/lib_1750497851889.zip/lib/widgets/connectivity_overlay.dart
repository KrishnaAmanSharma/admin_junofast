import 'package:flutter/material.dart';
import 'package:junofast/services/connectivity_service.dart';

class ConnectivityOverlay extends StatefulWidget {
  final Widget child;

  const ConnectivityOverlay({Key? key, required this.child}) : super(key: key);

  @override
  State<ConnectivityOverlay> createState() => _ConnectivityOverlayState();
}

class _ConnectivityOverlayState extends State<ConnectivityOverlay> {
  final ConnectivityService _connectivityService = ConnectivityService();
  bool _hasInternetConnection = true; // Default to true to allow initial app load
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _initializeConnectivity();
  }

  Future<void> _initializeConnectivity() async {
    try {
      // Listen to internet connection changes
      _connectivityService.internetConnectionStream.listen((hasConnection) {
        if (mounted) {
          setState(() {
            _hasInternetConnection = hasConnection;
            _isInitialized = true;
          });
        }
      });

    

      // Initial check for internet connection
      final hasConnection = await _connectivityService.checkInternetConnection();
      if (mounted) {
        setState(() {
          _hasInternetConnection = hasConnection;
          _isInitialized = true;
        });
      }
    } catch (e) {
      debugPrint('Error initializing connectivity listeners: $e');
      if (mounted) {
        setState(() {
          // Default to allowing app usage if we can't check
          _hasInternetConnection = true;
          _isInitialized = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // If not initialized yet, show the app content
    // This prevents flashing of error screens during initialization
    if (!_isInitialized) {
      return widget.child;
    }


    // If no internet connection, show warning
    if (!_hasInternetConnection) {
      return _buildNoInternetWarning();
    }

    // Otherwise, show the normal app content
    return widget.child;
  }

  Widget _buildNoInternetWarning() {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.signal_wifi_off,
                size: 80,
                color: Colors.red,
              ),
              const SizedBox(height: 20),
              const Text(
                'No Internet Connection',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'Please check your internet connection and try again.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () async {
                  try {
                    // Check internet connection again
                    final hasConnection = await _connectivityService.checkInternetConnection();
                    if (mounted) {
                      setState(() {
                        _hasInternetConnection = hasConnection;
                      });
                    }
                  } catch (e) {
                    debugPrint('Error checking internet connection: $e');
                  }
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUsbDebuggingWarning() {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.security,
                size: 80,
                color: Colors.red,
              ),
              const SizedBox(height: 20),
              const Text(
                'USB Debugging Enabled',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'For security reasons, please disable USB debugging in your device settings before using this app.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  // This will trigger a recheck of the USB debugging status
                  // through the periodic timer in the connectivity service
                },
                child: const Text('I\'ve Disabled USB Debugging'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    // No need to dispose the connectivity service here as it's a singleton
    // and might be used elsewhere in the app
    super.dispose();
  }
}