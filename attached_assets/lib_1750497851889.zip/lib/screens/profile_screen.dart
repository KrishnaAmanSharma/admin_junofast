import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/theme_config.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';
import '../widgets/custom_input_field.dart';
import '../widgets/custom_button.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  
  bool _isLoading = false;
  String? _errorMessage;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _loadUserData() {
    final authService = Provider.of<AuthService>(context, listen: false);
    final user = authService.currentUser;
    
    if (user != null) {
      setState(() {
        _emailController.text = user.email ?? '';
        _fullNameController.text = user.userMetadata?['full_name'] ?? '';
        _phoneController.text = user.userMetadata?['phone_number'] ?? '';
      });
    }
  }

  Future<void> _signOut() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.signOut();
      
      if (!mounted) return;
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to sign out: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.updateProfile(
        fullName: _fullNameController.text.trim(),
        phoneNumber: _phoneController.text.trim(),
      );
      _loadUserData(); // Reload user data to reflect changes
      setState(() {
        _isEditing = false;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to update profile: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Widget _buildProfileInfo() {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.person_outline, color: AppTheme.secondaryColor),
          title: const Text('Full Name', style: TextStyle(fontSize: 14, color: Colors.grey)),
          subtitle: Text(
            _fullNameController.text,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.email_outlined, color: AppTheme.secondaryColor),
          title: const Text('Email', style: TextStyle(fontSize: 14, color: Colors.grey)),
          subtitle: Text(
            _emailController.text,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.phone_outlined, color: AppTheme.secondaryColor),
          title: const Text('Phone', style: TextStyle(fontSize: 14, color: Colors.grey)),
          subtitle: Text(
            _phoneController.text.isEmpty ? 'Not set' : _phoneController.text,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }

  Widget _buildEditForm() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: CustomInputField(
            placeholder: 'Full name',
            controller: _fullNameController,
            keyboardType: TextInputType.name,
            enabled: true,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your full name';
              }
              return null;
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: CustomInputField(
            placeholder: 'Phone number',
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            enabled: true,
            validator: (value) {
              if (value != null && value.isNotEmpty) {
                if (!RegExp(r'^[0-9]{10}$').hasMatch(value)) {
                  return 'Please enter a valid 10-digit phone number';
                }
              }
              return null;
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Text(
                      'Profile',
                      style: AppTheme.headingStyle,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const SizedBox(height: 24),
                      Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          Container(
                            width: 120,
                            height: 120,
                            decoration: BoxDecoration(
                              color: AppTheme.inputBackgroundColor,
                              shape: BoxShape.circle,
                              border: Border.all(color: AppTheme.secondaryColor, width: 2),
                            ),
                            child: const Icon(
                              Icons.person,
                              size: 60,
                              color: AppTheme.secondaryColor,
                            ),
                          ),
                          if (_isEditing)
                            Container(
                              decoration: BoxDecoration(
                                color: AppTheme.secondaryColor,
                                shape: BoxShape.circle,
                              ),
                              child: IconButton(
                                icon: const Icon(Icons.camera_alt, color: Colors.white, size: 20),
                                onPressed: () {
                                  // Implement photo upload
                                },
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 32),
                      
                      _isEditing ? _buildEditForm() : _buildProfileInfo(),
                      
                      if (_errorMessage != null)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            _errorMessage!,
                            style: TextStyle(color: AppTheme.errorColor),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      
                      const SizedBox(height: 32),
                      
                      CustomButton(
                        text: _isEditing ? 'Save Profile' : 'Edit Profile',
                        onPressed: _isEditing ? _updateProfile : () {
                          setState(() {
                            _isEditing = true;
                          });
                        },
                        isLoading: _isLoading && _isEditing,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      CustomButton(
                        text: 'Sign Out',
                        onPressed: _signOut,
                        isLoading: _isLoading && !_isEditing,
                        isOutlined: true,
                      ),
                      
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}