import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:junofast/models/order_model.dart';
import 'dart:io';
import '../config/theme_config.dart';
import '../services/order_service.dart';
import '../widgets/custom_input_field.dart';
import '../widgets/map_location_picker.dart';

class EditOrderScreen extends StatefulWidget {
  final Map<String, dynamic> orderData;

  const EditOrderScreen({Key? key, required this.orderData}) : super(key: key);

  @override
  State<EditOrderScreen> createState() => _EditOrderScreenState();
}

class _EditOrderScreenState extends State<EditOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final OrderService _orderService = OrderService();
  final ImagePicker _picker = ImagePicker();
  
  // Form controllers
  final TextEditingController _pickupAddressController = TextEditingController();
  final TextEditingController _pickupPincodeController = TextEditingController();
  final TextEditingController _dropAddressController = TextEditingController();
  final TextEditingController _dropPincodeController = TextEditingController();
  
  String _selectedServiceType = '';
  double? _pickupLatitude;
  double? _pickupLongitude;
  List<Map<String, dynamic>> _commonItems = [];
  List<Map<String, dynamic>> _customItems = [];
  bool _isLoading = false;
  
  @override
  void initState() {
    super.initState();
    _initializeFormData();
  }
  
  // In the _EditOrderScreenState class
  List<Map<String, dynamic>> _questionAnswers = [];
  
  void _initializeFormData() {
    // Set service type (not editable)
    _selectedServiceType = widget.orderData['service_type'] ?? '';
    
    // Set address information
    _pickupAddressController.text = widget.orderData['pickup_address'] ?? '';
    _pickupPincodeController.text = widget.orderData['pickup_pincode'] ?? '';
    _dropAddressController.text = widget.orderData['drop_address'] ?? '';
    _dropPincodeController.text = widget.orderData['drop_pincode'] ?? '';
    
    // Set location coordinates if available
    _pickupLatitude = widget.orderData['pickup_latitude'];
    _pickupLongitude = widget.orderData['pickup_longitude'];
    
    // Set common items
    if (widget.orderData['common_items'] != null) {
      _commonItems = List<Map<String, dynamic>>.from(
        (widget.orderData['common_items'] as List).map((item) => Map<String, dynamic>.from(item))
      );
    }
    
    // Set custom items
    if (widget.orderData['custom_items'] != null) {
      _customItems = List<Map<String, dynamic>>.from(
        (widget.orderData['custom_items'] as List).map((item) => Map<String, dynamic>.from(item))
      );
    }
    
    // Set question answers
    if (widget.orderData['order_question_answers'] != null) {
      _questionAnswers = List<Map<String, dynamic>>.from(
        (widget.orderData['order_question_answers'] as List).map((item) => Map<String, dynamic>.from(item))
      );
    }
  }
  
  Future<void> _updateOrder() async {
    if (!_formKey.currentState!.validate()) return;
    
    try {
      setState(() => _isLoading = true);
      
      // Prepare order data
      final Map<String, dynamic> orderData = {
        'id': widget.orderData['id'],
        'service_type': _selectedServiceType,
        'pickup_address': _pickupAddressController.text,
        'pickup_pincode': _pickupPincodeController.text,
        'pickup_latitude': _pickupLatitude,
        'pickup_longitude': _pickupLongitude,
        'drop_address': _dropAddressController.text,
        'drop_pincode': _dropPincodeController.text,
        'common_items': _commonItems,
        'custom_items': _customItems,
        'question_answers': _questionAnswers, // Add question answers
      };
      
      // Update order
      await _orderService.updateOrder(OrderModel.fromJson(orderData));
      
      setState(() => _isLoading = false);
      
      // Show success message and return to previous screen
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Order updated successfully')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update order: $e')),
        );
      }
    }
  }

  void _showAddCustomItemDialog() {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final quantityController = TextEditingController(text: '1');
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Add Custom Item'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomInputField(
                enabled: true,
                controller: nameController,
                placeholder: 'Enter item name',
                validator: (value) => value!.isEmpty ? 'Please enter item name' : null,
              ),
              const SizedBox(height: 16),
              CustomInputField(
                enabled: true,
                controller: descriptionController,
                placeholder: 'Enter item description',
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              CustomInputField(
                enabled: true,
                controller: quantityController,
                placeholder: 'Enter quantity',
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) return 'Please enter quantity';
                  if (int.tryParse(value) == null || int.parse(value) < 1) {
                    return 'Please enter a valid quantity';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: AppTheme.bodyStyle.copyWith(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty && quantityController.text.isNotEmpty) {
                setState(() {
                  _customItems.add({
                    'name': nameController.text,
                    'description': descriptionController.text,
                    'quantity': int.parse(quantityController.text),
                    'photos': [],
                  });
                });
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(
              'Add Item',
              style: AppTheme.bodyStyle.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _attachPhotoToCustomItem(int index) async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        setState(() {
          if (_customItems[index]['photos'] == null) {
            _customItems[index]['photos'] = [];
          }
          _customItems[index]['photos'].add(image.path);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to pick image: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.primaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Edit Order',
          style: AppTheme.headingStyle.copyWith(fontSize: 22),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSectionTitle('Service Type'),
                    // Display service type as non-editable text
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        _selectedServiceType,
                        style: AppTheme.bodyStyle.copyWith(fontSize: 16),
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildSectionTitle('Pickup Details'),
                    CustomInputField(
                      enabled: true,
                      controller: _pickupAddressController,
                      placeholder: 'Enter pickup address',
                      maxLines: 3,
                      validator: (value) => value!.isEmpty ? 'Please enter pickup address' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomInputField(
                      enabled: true,
                      controller: _pickupPincodeController,
                      placeholder: 'Enter pickup pincode',
                      keyboardType: TextInputType.number,
                      validator: (value) => value!.isEmpty ? 'Please enter pickup pincode' : null,
                    ),
                    const SizedBox(height: 16),
                    _buildSectionTitle('Pickup Location'),
                    MapLocationPicker(
                      initialLatitude: _pickupLatitude,
                      initialLongitude: _pickupLongitude,
                      onLocationSelected: (latitude, longitude) {
                        setState(() {
                          _pickupLatitude = latitude;
                          _pickupLongitude = longitude;
                        });
                      },
                    ),
                    const SizedBox(height: 24),
                    _buildSectionTitle('Drop Details'),
                    CustomInputField(
                      enabled: true,
                      controller: _dropAddressController,
                      placeholder: 'Enter drop address',
                      maxLines: 3,
                      validator: (value) => value!.isEmpty ? 'Please enter drop address' : null,
                    ),
                    const SizedBox(height: 16),
                    CustomInputField(
                       enabled: true,
                      controller: _dropPincodeController,
                      placeholder: 'Enter drop pincode',
                      keyboardType: TextInputType.number,
                      validator: (value) => value!.isEmpty ? 'Please enter drop pincode' : null,
                    ),
                    const SizedBox(height: 24),
                    _buildSectionTitle('Items'),
                    _buildCommonItemsList(),
                    const SizedBox(height: 24),
                    _buildSectionTitle('Custom Items'),
                    _buildCustomItemsList(),
                    const SizedBox(height: 16),
                    Center(
                      child: OutlinedButton.icon(
                        onPressed: _showAddCustomItemDialog,
                        icon: const Icon(Icons.add, color: AppTheme.primaryColor),
                        label: Text(
                          'Add Custom Item',
                          style: AppTheme.bodyStyle.copyWith(color: AppTheme.primaryColor),
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          side: const BorderSide(color: AppTheme.primaryColor),
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _updateOrder,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryColor,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          'Update Order',
                          style: AppTheme.bodyStyle.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: AppTheme.headingStyle.copyWith(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildCommonItemsList() {
    if (_commonItems.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Text(
            'No common items selected',
            style: AppTheme.bodyStyle.copyWith(color: Colors.grey),
          ),
        ),
      );
    }
    
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _commonItems.length,
      itemBuilder: (context, index) {
        final item = _commonItems[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            title: Text(
              item['name'] ?? 'Unknown Item',
              style: AppTheme.bodyStyle.copyWith(fontWeight: FontWeight.bold),
            ),
            subtitle: Text('Quantity: ${item['quantity'] ?? 1}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      if (item['quantity'] > 1) {
                        item['quantity'] = item['quantity'] - 1;
                      } else {
                        _commonItems.removeAt(index);
                      }
                    });
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline, color: AppTheme.primaryColor),
                  onPressed: () {
                    setState(() {
                      item['quantity'] = (item['quantity'] ?? 1) + 1;
                    });
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCustomItemsList() {
    if (_customItems.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Text(
            'No custom items added',
            style: AppTheme.bodyStyle.copyWith(color: Colors.grey),
          ),
        ),
      );
    }
    
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _customItems.length,
      itemBuilder: (context, index) {
        final item = _customItems[index];
        final List<dynamic> photos = item['photos'] ?? [];
        
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item['name'] ?? 'Custom Item',
                            style: AppTheme.bodyStyle.copyWith(fontWeight: FontWeight.bold),
                          ),
                          if (item['description'] != null && item['description'].toString().isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                item['description'],
                                style: AppTheme.bodyStyle.copyWith(fontSize: 12),
                              ),
                            ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () {
                        setState(() => _customItems.removeAt(index));
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      'Quantity: ',
                      style: AppTheme.bodyStyle,
                    ),
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline, size: 20),
                      onPressed: () {
                        setState(() {
                          if (item['quantity'] > 1) {
                            item['quantity'] = item['quantity'] - 1;
                          }
                        });
                      },
                    ),
                    Text(
                      '${item['quantity'] ?? 1}',
                      style: AppTheme.bodyStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline, size: 20, color: AppTheme.primaryColor),
                      onPressed: () {
                        setState(() {
                          item['quantity'] = (item['quantity'] ?? 1) + 1;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Photos:',
                  style: AppTheme.bodyStyle.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 100,
                  child: Row(
                    children: [
                      ...photos.map((photo) => _buildPhotoItem(photo, index)).toList(),
                      _buildAddPhotoButton(index),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPhotoItem(String photoPath, int itemIndex) {
    return Container(
      width: 80,
      height: 80,
      margin: const EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        image: DecorationImage(
          image: FileImage(File(photoPath)),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.7),
              shape: BoxShape.circle,
            ),
            margin: const EdgeInsets.all(4),
            child: IconButton(
              icon: const Icon(Icons.close, size: 16, color: Colors.red),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              onPressed: () {
                setState(() {
                  _customItems[itemIndex]['photos'].remove(photoPath);
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddPhotoButton(int itemIndex) {
    return GestureDetector(
      onTap: () => _attachPhotoToCustomItem(itemIndex),
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: const Icon(
          Icons.add_a_photo_outlined,
          color: AppTheme.primaryColor,
        ),
      ),
    );
  }
}