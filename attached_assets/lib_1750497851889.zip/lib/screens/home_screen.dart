import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:junofast/screens/profile_screen.dart';
import 'package:provider/provider.dart';

import '../config/theme_config.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';
import './create_order_screen.dart';
import './orders_screen.dart';
import '../services/order_service.dart';
import '../models/order_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  
  final List<ServiceCategory> _services = [
    ServiceCategory(
      title: 'House Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB18SpNPiIwFkTVGh2ff3wZQARYEIbHAy7aOgv1elPMSMwMcswodlHef4Ozp4Xd-hhnc7U1IdQ70fLWmGeHWKu55bdr5wtuVUZqsHTX5HoAg321m-wG5MMh0GcGqmasYH_aIGLh8htkFJ7M4eikBqHOkOJwPq4dtN8rSJkYb8tRLpifqrOsxh1yEjpI5XUdBXT4yshK3Xih31uj6OBRhiWN6u7lNKlmalYuzVQNN7gU7TzxjS0iuBn8ABNCh12c-RvqDAgJHf4Zzg',
    ),
    ServiceCategory(
      title: 'Office Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBQq5hZ8IngedXGiwm1DODYL0eKfml5lfPUFNCv5rKFtA6dI5G7M2Nsifu0DrcFogxO9nxdN2RVM6XzpcRUIon_5izQxeo5t2OWU2AO0QI5_q7TMGlo2PN2EGMAdH2IXtNooI6jvfAeI47pRbZjPBPAq9He5xMKQ6WQzIpTCYblNuEBt8GXo97opetDDs9VXklONQ1tOei08j4FhhxP2Hfw-_zUf7CuTlc-Gn6Ju1vxNldf7NOkw5ic2igGRyUa6Jl4G4nZD7dfVQ',
    ),
    ServiceCategory(
      title: 'PG Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAD9BmAFIWWd79fUDxq_2S-hsF14E4AIhDKQC8ByeZbVMYUm8lXgWieGdG8HxVKsJLfRoJKtXcBIgwGeYm9jyTjaegQc3GBIjAjAyqzC6ZgtohLeKX7X9B7_v_J0VnoxnR3JYcQfBvqx8O2ydnjA6ll89jyma82q0o3xtuAz0cQpJ-bx_LLRu03CciDb2tvGsfhOpP70JZpQDcn5dvZulhdkglv5534_v-pV7KTksTkAqcWbdc1qpFDZWfywEmNAei2ODwk17h2qQ',
    ),
    ServiceCategory(
      title: 'Automotive Vehicle Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDcGEqMlD7mgwJKh5cETIpUpqfIYvTAZxQMnQp07eHYltazv3L5os4krqNgoadzuVMtdqCm8Z7JxHTv4lik1-utBawis1gyy3LN80ZYrpKpjx_thfJHO3QAlmcoFrNCff6po_hecTkPZXhAYLxOTHDc7B5IyLsbY8BZShH57KfvqUSuV-CMpUs3Je_LJ5VLq3jVtpLA5Z3jOl74cZXzOcRZKAhhualC6oJBWKrAy5ieYwVf9WseoOePOs8vIiVit3atGlIXPEmY2g',
    ),
    ServiceCategory(
      title: 'Pets Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVLxkLLGiZV9W9Z3FQMRv5F-OXglO11OVlEFnaJXNWyCbOH0r6XN_ZqF9i8oBhIkGpVrVBRItv61bu3PLbUDU39g8zHp6rTo2ruUaQcnMxR378Qe9D8eCK3dPvHqK_toIdIWKsrxrVgUx-j419_bLAC8_Xu0TJvzf9UFszX-JRFnI16sDD_9ZCg6ukcdQ_FJcrwJboqmR6G55zTzWk9mt7hFkb1KgQ4H5PRItesVQDgnGS7yfK4f7ZhB6LUwJCkeIEX5j7YF0idQ',
    ),
    ServiceCategory(
      title: 'Motorsports Vehicle Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCbXDDzN6JxhDAMtaXjHXKdmZ1ZQ0IoLpHS8-O-lJFsB2yGLCkZSm064UQXY0gdv5FLNGDhZlLBaJVA6mmRf4iyLcN8hUdzRyAtwJnFV3tRVZAUR3-Bv8npSzwRZzG9dWvmo00MIkyDj7PhpOF01tLMItnPcqbsYrmRWALqr_Lhq30kqNU38M4u8CEIJsI8nbx1NHyNrACpsszmLiA1h2yI39ebdQWAAtGkghE8wIyRCp2EtFFFh3KVPWslt5aapoKpzdjvTvq5ow',
    ),
    ServiceCategory(
      title: 'Industrial Shipments',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCoZNffTDuKjjWb46V4ZX_0_0L7ytQ04JxmKgPcyduKLpKz2w7K77k1fnrAvcD7-lOQa1REFKSIou9UzCk9I6HHytmBFUkn01eiVElGsSnskfxavVPs6rQ-3ztCFtyhdyNSI6IjzqVdUwKgKPZRtMOHeCLEup8p3tFTcc08qmO9_6loVsbShpRwAGcwnZGJwxvKFZ1o5YEbdZoptgW6e14hlNx7S6aLSOZ3cujZnQ8y65kaAe3yB8o6VXAo1h2tvIV1u1mKwnD4VA',
    ),
    ServiceCategory(
      title: 'Events & Exhibitions Relocation',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBn-BbmpZMXctaiz1kOz30lWvPQzymQsd5E-4k1SKMH9sRKNtz12odihb9VMvi0Ti70W5ESByVFqe9FRpaTwV6oh2uPVMltujGKiCF-_9RG8x3sCJ704Rubslj95Dlde_N6KaSoOZIxKx2RNCSyXw9gN6Xrdt8FVoPzg9XEqN6G8n9lapOXsqAa6UBGfMmJWE_5UIU5xVcLmz4mpYv8HuTrBx9U9eSuHS-jVnvO2OynAqDXr6fRkKVqosEo3ZEvjX30QU_dfDceXQ',
    ),
    ServiceCategory(
      title: 'Courier/Parcel Service',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBGaiGpT9P8dadrX3wNpBa_cPx90Jbug5j392SLXfmie8xz3MWe4AAsHeAA4YFY8KaT57EVTkADCYSepeX6hdVX5zU84lXEvN7EX0_c3CAAmph4kqnDBU31FQ_obN7__ctljLDJEqugiOnMLDvasFo08uTgwFIDknW0kOhctk0bixn8IWjTKBLEN3loRSo4kb-nJXVtExo8fzBrnAuKy1cvDjnJFEYps8dBPrF44xJu18aTxTk5bTYQw5LGUPY3OZwGD6bT_DO8OA',
    ),
  ];
  
  final OrderService _orderService = OrderService();
  bool _isLoadingOngoing = true;
  List<OrderModel> _ongoingOrders = [];

  @override
  void initState() {
    super.initState();
    _fetchOngoingOrders();
  }

  Future<void> _fetchOngoingOrders() async {
    setState(() {
      _isLoadingOngoing = true;
    });
    try {
      final orders = await _orderService.getUserOrders();
      // Ongoing = not completed/cancelled
      final ongoing = orders.where((order) {
        final status = order.status.toLowerCase();
        return status == 'pending' ||
               status == 'price updated' ||
               status == 'price accepted' ||
               status == 'in progress';
      }).take(2).toList();
      setState(() {
        _ongoingOrders = ongoing;
        _isLoadingOngoing = false;
      });
    } catch (e) {
      setState(() {
        _ongoingOrders = [];
        _isLoadingOngoing = false;
      });
    }
  }

  Future<bool> _showExitDialog() async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Exit App'),
        content: const Text('Are you sure you want to exit the app?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Exit'),
          ),
        ],
      ),
    ) ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final user = authService.currentUser;
    final userName = user?.email?.split('@').first ?? 'Alex';

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        
        if (_currentIndex != 0) {
          // If not on home tab, go back to home tab
          setState(() {
            _currentIndex = 0;
          });
        } else {
          // If on home tab, show exit dialog
          final shouldExit = await _showExitDialog();
          if (shouldExit) {
            // Exit the app using SystemNavigator.pop()
            SystemNavigator.pop();
          }
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: _currentIndex == 0 
            ? _buildHomeContent(userName) 
            : _currentIndex == 2 
                ? const OrdersScreen() 
                : _currentIndex == 3
                  ? const ProfileScreen()
                  : const Center(child: Text('Coming Soon')),
        bottomNavigationBar: _buildBottomNavBar(),
      ),
    );
  }

  Widget _buildHomeContent(String userName) {
    return SafeArea(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // App bar with title and notification icon
                  Padding(
                    padding: const EdgeInsets.all(16.0).copyWith(bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Relocator',
                            style: AppTheme.headingStyle,
                            textAlign: TextAlign.center,
                          ),
                        ),
                        // Container(
                        //   width: 48,
                        //   height: 48,
                        //   decoration: BoxDecoration(
                        //     shape: BoxShape.circle,
                        //   ),
                        //   child: IconButton(
                        //     icon: const Icon(
                        //       Icons.notifications_outlined,
                        //       color: AppTheme.primaryColor,
                        //     ),
                        //     onPressed: () {},
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                  
                  // Welcome message
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Welcome back, $userName',
                          style: AppTheme.headingStyle.copyWith(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Ready to plan your next move? We\'re here to help you every step of the way.',
                          style: AppTheme.bodyStyle,
                        ),
                      ],
                    ),
                  ),
                  
                  // Ongoing Jobs section
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      'Ongoing Jobs',
                      style: AppTheme.headingStyle.copyWith(
                        fontSize: 22,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  
                  // Ongoing jobs list (real data)
                  if (_isLoadingOngoing)
                    const Center(child: CircularProgressIndicator()),
                  if (!_isLoadingOngoing && _ongoingOrders.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        'No ongoing jobs',
                        style: AppTheme.bodyStyle.copyWith(color: Colors.grey),
                      ),
                    ),
                  if (!_isLoadingOngoing && _ongoingOrders.isNotEmpty)
                    ..._ongoingOrders.map((order) => _buildOngoingOrderCard(order)),
                  
                  // Our Services section
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      'Our Services',
                      style: AppTheme.headingStyle.copyWith(
                        fontSize: 22,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  
                  // Horizontal scrolling services
                  SizedBox(
                    height: 240,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _services.length,
                      itemBuilder: (context, index) {
                        final service = _services[index];
                        return ServiceCard(
                          title: service.title,
                          imageUrl: service.imageUrl,
                          onTap: () {
                            // Navigate to service details
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: const Color(0xFFF0F2F4),
            width: 1,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(0, 'House', _currentIndex == 0),
          _buildNavItem(1, 'PlusSquare', false),
          _buildNavItem(2, 'List', _currentIndex == 2),
          _buildNavItem(3, 'User', _currentIndex == 3),
        ],
      ),
    );
  }

  Widget _buildNavItem(int index, String iconName, bool isSelected) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (index == 1) {
            // Navigate to Create Order screen when plus icon is tapped
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const CreateOrderScreen()),
            );
          } else {
            setState(() {
              _currentIndex = index;
            });
          }
        },
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _getIconData(iconName),
              color: isSelected ? AppTheme.primaryColor : const Color(0xFF617789),
              size: 24,
            ),
          ],
        ),
      ),
    );
  }
  
  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'House':
        return Icons.home;
      case 'PlusSquare':
        return Icons.add_box_outlined;
      case 'List':
        return Icons.list;
      case 'User':
        return Icons.person_outline;
      case 'Car':
        return Icons.directions_car_outlined;
      default:
        return Icons.circle;  
    }
  }

  Widget _buildOngoingOrderCard(OrderModel order) {
    // You can customize this card as needed
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF0F2F5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.assignment, color: AppTheme.primaryColor, size: 32),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  order.serviceType,
                  style: AppTheme.bodyStyle.copyWith(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Text(
                  order.status,
                  style: AppTheme.bodyStyle.copyWith(color: AppTheme.secondaryColor, fontSize: 14),
                ),
                Text(
                  'Pickup: ${order.pickupAddress}',
                  style: AppTheme.bodyStyle.copyWith(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'Drop: ${order.dropAddress}',
                  style: AppTheme.bodyStyle.copyWith(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          // Icon(Icons.arrow_forward_ios, size: 16, color: AppTheme.secondaryColor),
        ],
      ),
    );
  }
}

class ServiceCategory {
  final String title;
  final String imageUrl;

  ServiceCategory({
    required this.title,
    required this.imageUrl,
  });
}

class ServiceCard extends StatelessWidget {
  final String title;
  final String imageUrl;
  final VoidCallback onTap;

  const ServiceCard({
    Key? key,
    required this.title,
    required this.imageUrl,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 200, // Reduced width slightly
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Service image
            Expanded( // Use Expanded instead of AspectRatio
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: AppTheme.inputBackgroundColor,
                      child: const Center(
                        child: Icon(Icons.image_not_supported),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 8), // Reduced spacing
            // Service title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                title,
                style: AppTheme.bodyStyle.copyWith(
                  fontWeight: FontWeight.w500,
                  fontSize: 14, // Slightly smaller font
                ),
                maxLines: 2, // Allow 2 lines for longer titles
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.start,
              ),
            ),
            const SizedBox(height: 8), // Add bottom padding
          ],
        ),
      ),
    );
  }
}