import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Colors
  static const Color primaryColor = Color(0xFF111518);
  static const Color secondaryColor = Color(0xFF60768A);
  static const Color backgroundColor = Colors.white;
  static const Color inputBackgroundColor = Color(0xFFF0F2F5);
  static const Color errorColor = Color(0xFFE53935);
  
  // Text Styles
  static TextStyle get headingStyle => GoogleFonts.publicSans(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: primaryColor,
        letterSpacing: -0.015,
      );
  
  static TextStyle get bodyStyle => GoogleFonts.publicSans(
        fontSize: 16,
        fontWeight: FontWeight.normal,
        color: primaryColor,
      );
  
  static TextStyle get inputStyle => GoogleFonts.publicSans(
        fontSize: 16,
        fontWeight: FontWeight.normal,
        color: primaryColor,
      );
  
  static TextStyle get placeholderStyle => GoogleFonts.publicSans(
        fontSize: 16,
        fontWeight: FontWeight.normal,
        color: secondaryColor,
      );
  
  // Theme Data
  static ThemeData get lightTheme => ThemeData(
        primaryColor: primaryColor,
        scaffoldBackgroundColor: backgroundColor,
        colorScheme: ColorScheme.light(
          primary: primaryColor,
          secondary: secondaryColor,
          error: errorColor,
          background: backgroundColor,
        ),
        textTheme: TextTheme(
          displayLarge: headingStyle,
          bodyLarge: bodyStyle,
          bodyMedium: bodyStyle,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: inputBackgroundColor,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: errorColor),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          hintStyle: placeholderStyle,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryColor,
            foregroundColor: Colors.white,
            minimumSize: Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: GoogleFonts.publicSans(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      );
}