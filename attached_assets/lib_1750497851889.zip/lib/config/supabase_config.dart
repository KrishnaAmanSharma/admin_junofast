import 'package:flutter/foundation.dart';

class SupabaseConfig {
  // Replace with your Supabase URL and anon key
  static const String supabaseUrl = 'https://tdqqrjssnylfbjmpgaei.supabase.co';
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRkcXFyanNzbnlsZmJqbXBnYWVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk3NDUzNjAsImV4cCI6MjA2NTMyMTM2MH0.d0zoAkDbbOA3neeaFRzeoLkeyV6vt-2JFeOlAnhSfIw';
  
  // Google OAuth client ID
  static const String googleClientId = 'YOUR_GOOGLE_CLIENT_ID';
  
  // Debug mode flag
  static bool get isDebugMode => kDebugMode;
}